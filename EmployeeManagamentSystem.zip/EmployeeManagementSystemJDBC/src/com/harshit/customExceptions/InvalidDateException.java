package com.harshit.customExceptions;

public class InvalidDateException extends Exception{
	
	public InvalidDateException(String message) {
		super(message);
	}

}
