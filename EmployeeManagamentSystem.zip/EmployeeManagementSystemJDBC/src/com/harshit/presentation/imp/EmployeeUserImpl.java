package com.harshit.presentation.imp;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.harshit.customExceptions.InvalidDateException;
import com.harshit.entity.Employee;
import com.harshit.persistence.EmployeeDAOInterface;
import com.harshit.persistence.impl.EmployeeDAOImpl;
import com.harshit.presentation.EmployeeUserInterface;
import com.harshit.utility.TakeInput;

public class EmployeeUserImpl implements EmployeeUserInterface {

	@Override
	public void showEmployeeMenu() {
		System.out.println("1. Insert Customer");

		System.out.println("6. Exit");		
	}

	@Override
	public void performOnEmployeeMenu(int choice) throws SQLException, IOException, InvalidDateException {
		Scanner sc = new Scanner(System.in);
		EmployeeDAOInterface employeeDAO;

		switch(choice) {
		case 1:
		{
			employeeDAO = new EmployeeDAOImpl();
			Employee employee = TakeInput.takeInput(sc);
			boolean result = employeeDAO.insertEmployee(employee);
			if(result)
				System.out.println("Employee added.");
			else 
				System.out.println("Employee Not Added");
		}break;

		case 6 :{
			System.out.println("BYE !");
			System.exit(0);
		} break;
		default:{
			System.out.println("Wrong Input !");
		}
		}
	}

}
