package com.harshit.presentation;

import java.io.IOException;
import java.sql.SQLException;

import com.harshit.customExceptions.InvalidDateException;

public interface EmployeeUserInterface {

	void showEmployeeMenu();
	void performOnEmployeeMenu(int choice) throws SQLException, IOException, InvalidDateException;

}
