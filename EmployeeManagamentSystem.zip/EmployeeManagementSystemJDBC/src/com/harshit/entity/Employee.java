package com.harshit.entity;

import java.sql.Date;

import com.harshit.customExceptions.InvalidDateException;

public class Employee {
	private String firstName;
	private String lastName;
	private String employeeId;
	private String employeeAddress;
	private String dateOfBirth;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmpId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) throws InvalidDateException {
		int dd = Integer.parseInt(dateOfBirth.substring(0,2));
		int mm = Integer.parseInt(dateOfBirth.substring(3,5));
		int yy = Integer.parseInt(dateOfBirth.substring(6));
		int[] arr = {31,yy%4==0?29:28,31,30,31,30,31,31,30,31,30,31};
		if(yy>2019){
			throw new InvalidDateException("Wrong Year Input");
		}else {
			if(mm>12){
				throw new InvalidDateException("Wrong Month Input");
			}else {
				if(dd>arr[mm-1]){
					throw new InvalidDateException("Wrong Date");
				}else {
					this.dateOfBirth = dateOfBirth;
				}
			}
		}
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", empId=");
		builder.append(employeeId);
		builder.append(", employeeAddress=");
		builder.append(employeeAddress);
		builder.append(", dateOfBirth=");
		builder.append(dateOfBirth);
		builder.append("]");
		return builder.toString();
	}
	public Employee(String firstName, String lastName, String empId, String employeeAddress, String dateOfBirth) throws InvalidDateException {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = empId;
		this.employeeAddress = employeeAddress;
		int dd = Integer.parseInt(dateOfBirth.substring(0,2));
		int mm = Integer.parseInt(dateOfBirth.substring(3,5));
		int yy = Integer.parseInt(dateOfBirth.substring(6));
		int[] arr = {31,yy%4==0?29:28,31,30,31,30,31,31,30,31,30,31};
		if(yy>2019){
			throw new InvalidDateException("Wrong Year Input");
		}else {
			if(mm>12){
				throw new InvalidDateException("Wrong Month Input");
			}else {
				if(dd>arr[mm-1]){
					throw new InvalidDateException("Wrong Date");
				}else {
					this.dateOfBirth = dateOfBirth;
				}
			}
		}	}

	public Employee() {
	}


}
