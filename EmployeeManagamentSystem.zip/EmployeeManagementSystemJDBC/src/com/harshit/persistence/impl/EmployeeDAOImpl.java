package com.harshit.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.harshit.entity.Employee;
import com.harshit.persistence.EmployeeDAOInterface;
import com.harshit.utility.ConnectionUtility;

public class EmployeeDAOImpl implements EmployeeDAOInterface {


	public static final String INSERT_EMPLOYEE ="INSERT INTO EMP VALUES(?,?,?,?,?)";
	
	@Override
	public boolean insertEmployee(Employee employee) throws SQLException {

		Connection connection=ConnectionUtility.getMyConnection();
		connection.setAutoCommit(false);

		PreparedStatement preparedStatement=connection.prepareStatement(INSERT_EMPLOYEE);
		preparedStatement.setString(1, employee.getFirstName());
		preparedStatement.setString(2, employee.getLastName());
		preparedStatement.setString(3, employee.getEmployeeId());
		preparedStatement.setString(4, employee.getDateOfBirth());
		preparedStatement.setString(5, employee.getEmployeeAddress());

	
		int result=0;
		try {
			result = preparedStatement.executeUpdate();
			connection.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			connection.rollback();		}
		connection.close();
		if(result>0)
			return true;
		return false;
	}


}
