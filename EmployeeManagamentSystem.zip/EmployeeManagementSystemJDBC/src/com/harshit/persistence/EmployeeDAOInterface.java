package com.harshit.persistence;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.harshit.entity.Employee;

public interface EmployeeDAOInterface {
	
	public boolean insertEmployee(Employee employee) throws SQLException;
	


}
